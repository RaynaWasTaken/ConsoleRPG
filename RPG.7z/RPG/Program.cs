﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RPG
{
    public class Program
    {

        public static void Main(string[] args)
        {
            static String playername1;
            Console.Title = ("Totally good RPG");
            Console.WriteLine("What is your name?");
            Console.ReadLine();
            playername1 = Console.ReadLine();
        }
    }
}


        