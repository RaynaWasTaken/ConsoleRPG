﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace RPG
{
        public class Character
        {
            public String name;
            public int defense;
            public int attack;
            public int hp;
            public string faction;
        }

        class Player : Character
        {
            public void constructplayer()
            {
                name = Program.playername1;
                defense = 5;
                attack = 10;
                hp = 100;
            }
        }



        class Enemy : Character
        {
            public void constructenemy()
            {
                name = ("Goblin");
                defense = 2;
                attack = 5;
                hp = 50;
          
            }     
        }  
}

